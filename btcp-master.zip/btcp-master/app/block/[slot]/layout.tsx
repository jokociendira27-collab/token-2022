'use client';

import { Address } from '@components/common/Address';
import { Epoch } from '@components/common/Epoch';
import { ErrorCard } from '@components/common/ErrorCard';
import { ExternalLinkWarning } from '@components/common/ExternalLinkWarning';
import { LoadingCard } from '@components/common/LoadingCard';
import { Slot } from '@components/common/Slot';
import { TableCardBody } from '@components/common/TableCardBody';
import { estimateRequestedComputeUnits } from '@entities/compute-unit';
import { BlockProvider, FetchStatus, useBlock, useFetchBlock } from '@providers/block';
import { useCluster } from '@providers/cluster';
import { ClusterStatus } from '@utils/cluster';
import { displayTimestamp, displayTimestampUtc } from '@utils/date';
import { IBRL_EXPLORER_URL } from '@utils/env';
import { notFound, useSearchParams } from 'next/navigation';
import React, { PropsWithChildren } from 'react';
import { ExternalLink } from 'react-feather';

import { type NavigationTab, NavigationTabs } from '@/app/shared/ui/navigation-tabs';
import { StickyHeader } from '@/app/shared/ui/sticky-header/StickyHeader';
import { getEpochForSlot, getMaxComputeUnitsInBlock } from '@/app/utils/epoch-schedule';
import { pickClusterParams } from '@/app/utils/url';

type Props = PropsWithChildren<{ params: { slot: string } }>;

function BlockLayoutInner({ children, params: { slot } }: Props) {
    const slotNumber = Number(slot);
    if (isNaN(slotNumber) || slotNumber >= Number.MAX_SAFE_INTEGER || slotNumber % 1 !== 0) {
        notFound();
    }
    const confirmedBlock = useBlock(slotNumber);
    const fetchBlock = useFetchBlock();
    const { clusterInfo, status, cluster } = useCluster();
    const refresh = () => fetchBlock(slotNumber);

    // Fetch block on load
    React.useEffect(() => {
        if (!confirmedBlock && status === ClusterStatus.Connected) refresh();
    }, [slotNumber, status]); // eslint-disable-line react-hooks/exhaustive-deps

    let content;
    if (!confirmedBlock || confirmedBlock.status === FetchStatus.Fetching) {
        content = <LoadingCard message="Loading block" />;
    } else if (confirmedBlock.data === undefined || confirmedBlock.status === FetchStatus.FetchFailed) {
        content = <ErrorCard retry={refresh} text="Failed to fetch block" />;
    } else if (confirmedBlock.data.block === undefined) {
        content = <ErrorCard retry={refresh} text={`Block ${slotNumber} was not found`} />;
    } else {
        const { block, blockLeader, childSlot, childLeader, parentLeader } = confirmedBlock.data;
        const epoch = clusterInfo ? getEpochForSlot(clusterInfo.epochSchedule, BigInt(slotNumber)) : undefined;

        let totalCUs = 0;
        let totalRequestedCUs = 0;
        let totalCostUnits = 0;
        for (const tx of block.transactions) {
            const requestedCUs = estimateRequestedComputeUnits(tx, epoch, cluster);
            const cus = tx.meta?.computeUnitsConsumed ?? 0;
            const costUnits = tx.meta?.costUnits ?? 0;
            totalRequestedCUs += requestedCUs;
            totalCUs += cus;
            totalCostUnits += costUnits;
        }

        const showSuccessfulCount = block.transactions.every(tx => tx.meta !== null);
        const successfulTxs = block.transactions.filter(tx => tx.meta?.err === null);
        const maxComputeUnits = getMaxComputeUnitsInBlock({ cluster, epoch });

        content = (
            <>
                <div className="card">
                    <div className="card-header align-items-center">
                        <h3 className="card-header-title">Overview</h3>
                        {IBRL_EXPLORER_URL && (
                            <ExternalLinkWarning href={`${IBRL_EXPLORER_URL}/block/${slotNumber}`}>
                                <>
                                    <ExternalLink className="e-me-2 e-align-text-top" size={13} />
                                    IBRL Explorer
                                </>
                            </ExternalLinkWarning>
                        )}
                    </div>
                    <TableCardBody>
                        <tr>
                            <td className="w-100">Blockhash</td>
                            <td className="text-lg-end font-monospace">
                                <span>{block.blockhash}</span>
                            </td>
                        </tr>
                        <tr>
                            <td className="w-100">Slot</td>
                            <td className="text-lg-end font-monospace">
                                <Slot slot={slotNumber} />
                            </td>
                        </tr>
                        {blockLeader !== undefined && (
                            <tr>
                                <td className="w-100">Slot Leader</td>
                                <td className="text-lg-end">
                                    <Address pubkey={blockLeader} alignRight link />
                                </td>
                            </tr>
                        )}
                        {block.blockTime ? (
                            <>
                                <tr>
                                    <td>Timestamp (Local)</td>
                                    <td className="text-lg-end">
                                        <span className="font-monospace">
                                            {displayTimestamp(block.blockTime * 1000, true)}
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Timestamp (UTC)</td>
                                    <td className="text-lg-end">
                                        <span className="font-monospace">
                                            {displayTimestampUtc(block.blockTime * 1000, true)}
                                        </span>
                                    </td>
                                </tr>
                            </>
                        ) : (
                            <tr>
                                <td className="w-100">Timestamp</td>
                                <td className="text-lg-end">Unavailable</td>
                            </tr>
                        )}
                        {epoch !== undefined && (
                            <tr>
                                <td className="w-100">Epoch</td>
                                <td className="text-lg-end font-monospace">
                                    <Epoch epoch={epoch} link />
                                </td>
                            </tr>
                        )}
                        <tr>
                            <td className="w-100">Parent Blockhash</td>
                            <td className="text-lg-end font-monospace">
                                <span>{block.previousBlockhash}</span>
                            </td>
                        </tr>
                        <tr>
                            <td className="w-100">Parent Slot</td>
                            <td className="text-lg-end font-monospace">
                                <Slot slot={block.parentSlot} link />
                            </td>
                        </tr>
                        {parentLeader !== undefined && (
                            <tr>
                                <td className="w-100">Parent Slot Leader</td>
                                <td className="text-lg-end">
                                    <Address pubkey={parentLeader} alignRight link />
                                </td>
                            </tr>
                        )}
                        {childSlot !== undefined && (
                            <tr>
                                <td className="w-100">Child Slot</td>
                                <td className="text-lg-end font-monospace">
                                    <Slot slot={childSlot} link />
                                </td>
                            </tr>
                        )}
                        {childLeader !== undefined && (
                            <tr>
                                <td className="w-100">Child Slot Leader</td>
                                <td className="text-lg-end">
                                    <Address pubkey={childLeader} alignRight link />
                                </td>
                            </tr>
                        )}
                        <tr>
                            <td className="w-100">Processed Transactions</td>
                            <td className="text-lg-end font-monospace">
                                <span>{block.transactions.length}</span>
                            </td>
                        </tr>
                        {showSuccessfulCount && (
                            <tr>
                                <td className="w-100">Successful Transactions</td>
                                <td className="text-lg-end font-monospace">
                                    <span>{successfulTxs.length}</span>
                                </td>
                            </tr>
                        )}
                        <tr>
                            <td className="w-100">Total Compute Units Consumed</td>
                            <td className="text-lg-end font-monospace">
                                <span>{totalCUs.toLocaleString()}</span>
                            </td>
                        </tr>
                        <tr>
                            <td className="w-100">Transaction Cost Utilization</td>
                            <td className="text-lg-end font-monospace">
                                <span>
                                    {totalCostUnits.toLocaleString()} / {maxComputeUnits.toLocaleString()} (
                                    {Math.round((totalCostUnits / maxComputeUnits) * 100)}%)
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td className="w-100">Reserved Compute Units</td>
                            <td className="text-lg-end font-monospace">
                                <span>
                                    {totalRequestedCUs.toLocaleString()} / {maxComputeUnits.toLocaleString()} (
                                    {Math.round((totalRequestedCUs / maxComputeUnits) * 100)}%)
                                </span>
                            </td>
                        </tr>
                    </TableCardBody>
                </div>
                <MoreSection slot={slotNumber}>{children}</MoreSection>
            </>
        );
    }
    return (
        <div className="container mt-n3">
            <div className="header">
                <div className="header-body">
                    <h6 className="header-pretitle">Details</h6>
                    <h2 className="header-title">Block</h2>
                </div>
            </div>
            {content}
        </div>
    );
}

export default function BlockLayout({ children, params }: Props) {
    return (
        <BlockProvider>
            <BlockLayoutInner params={params}>{children}</BlockLayoutInner>
        </BlockProvider>
    );
}

const TABS: NavigationTab[] = [
    { path: '', title: 'Transactions' },
    { path: 'rewards', title: 'Rewards' },
    { path: 'programs', title: 'Programs' },
    { path: 'accounts', title: 'Accounts' },
];

function MoreSection({ children, slot }: { children: React.ReactNode; slot: number }) {
    const searchParams = useSearchParams();
    const buildHref = React.useCallback(
        (path: string) => pickClusterParams(`/block/${slot}/${path}`, searchParams ?? undefined),
        [slot, searchParams],
    );

    return (
        <>
            <StickyHeader>
                <div className="container">
                    <NavigationTabs buildHref={buildHref} tabs={TABS} />
                </div>
            </StickyHeader>
            {children}
        </>
    );
}

import { AccountAddressRow, AccountBalanceRow } from '@components/common/Account';
import { Address } from '@components/common/Address';
import { useRefreshAccount } from '@entities/account';
import { AccountCard } from '@features/account';
import { Account } from '@providers/accounts';
import { PublicKey } from '@solana/web3.js';
import { ConfigAccount, StakeConfigInfoAccount, ValidatorInfoAccount } from '@validators/accounts/config';
import React from 'react';

const MAX_SLASH_PENALTY = Math.pow(2, 8);

export function ConfigAccountSection({ account, configAccount }: { account: Account; configAccount: ConfigAccount }) {
    switch (configAccount.type) {
        case 'stakeConfig':
            return <StakeConfigCard account={account} configAccount={configAccount} />;
        case 'validatorInfo':
            return <ValidatorInfoCard account={account} configAccount={configAccount} />;
    }
}

function StakeConfigCard({ account, configAccount }: { account: Account; configAccount: StakeConfigInfoAccount }) {
    const refresh = useRefreshAccount();

    const warmupCooldownFormatted = new Intl.NumberFormat('en-US', {
        maximumFractionDigits: 2,
        style: 'percent',
    }).format(configAccount.info.warmupCooldownRate);

    const slashPenaltyFormatted = new Intl.NumberFormat('en-US', {
        maximumFractionDigits: 2,
        style: 'percent',
    }).format(configAccount.info.slashPenalty / MAX_SLASH_PENALTY);

    return (
        <AccountCard
            title="Stake Config"
            account={account}
            analyticsSection="stake_config_section"
            refresh={() => refresh(account.pubkey, 'parsed')}
        >
            <AccountAddressRow account={account} />
            <AccountBalanceRow account={account} />

            <tr>
                <td>Warmup / Cooldown Rate</td>
                <td className="text-lg-end">{warmupCooldownFormatted}</td>
            </tr>

            <tr>
                <td>Slash Penalty</td>
                <td className="text-lg-end">{slashPenaltyFormatted}</td>
            </tr>
        </AccountCard>
    );
}

function ValidatorInfoCard({ account, configAccount }: { account: Account; configAccount: ValidatorInfoAccount }) {
    const refresh = useRefreshAccount();
    return (
        <AccountCard
            title="Validator Info"
            account={account}
            analyticsSection="validator_info_section"
            refresh={() => refresh(account.pubkey, 'parsed')}
        >
            <AccountAddressRow account={account} />
            <AccountBalanceRow account={account} />

            {configAccount.info.configData.name && (
                <tr>
                    <td>Name</td>
                    <td className="text-lg-end">{configAccount.info.configData.name}</td>
                </tr>
            )}

            {configAccount.info.configData.keybaseUsername && (
                <tr>
                    <td>Keybase Username</td>
                    <td className="text-lg-end">{configAccount.info.configData.keybaseUsername}</td>
                </tr>
            )}

            {configAccount.info.configData.website && (
                <tr>
                    <td>Website</td>
                    <td className="text-lg-end">
                        <a href={configAccount.info.configData.website} target="_blank" rel="noopener noreferrer">
                            {configAccount.info.configData.website}
                        </a>
                    </td>
                </tr>
            )}

            {configAccount.info.configData.details && (
                <tr>
                    <td>Details</td>
                    <td className="text-lg-end">{configAccount.info.configData.details}</td>
                </tr>
            )}

            {configAccount.info.keys && configAccount.info.keys.length > 1 && (
                <tr>
                    <td>Signer</td>
                    <td className="text-lg-end">
                        <Address pubkey={new PublicKey(configAccount.info.keys[1].pubkey)} link alignRight />
                    </td>
                </tr>
            )}
        </AccountCard>
    );
}

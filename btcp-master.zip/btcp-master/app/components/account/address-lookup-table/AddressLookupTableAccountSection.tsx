import { Address } from '@components/common/Address';
import { Slot } from '@components/common/Slot';
import { SolBalance } from '@components/common/SolBalance';
import { useRefreshAccount } from '@entities/account';
import { AccountCard } from '@features/account';
import { Account } from '@providers/accounts';
import { AddressLookupTableAccount } from '@solana/web3.js';
import { AddressLookupTableAccountInfo } from '@validators/accounts/address-lookup-table';
import React from 'react';

export function AddressLookupTableAccountSection(
    params:
        | {
              account: Account;
              data: Uint8Array;
          }
        | {
              account: Account;
              lookupTableAccount: AddressLookupTableAccountInfo;
          },
) {
    const account = params.account;
    const lookupTableState = React.useMemo(() => {
        if ('data' in params) {
            return AddressLookupTableAccount.deserialize(params.data);
        } else {
            return params.lookupTableAccount;
        }
    }, [params]);
    const lookupTableAccount = new AddressLookupTableAccount({
        key: account.pubkey,
        state: lookupTableState,
    });
    const refresh = useRefreshAccount();
    return (
        <AccountCard
            title="Address Lookup Table Account"
            account={account}
            analyticsSection="address_lookup_table_section"
            refresh={() => refresh(account.pubkey, 'parsed')}
        >
            <tr>
                <td>Address</td>
                <td className="text-lg-end">
                    <Address pubkey={account.pubkey} alignRight raw />
                </td>
            </tr>
            <tr>
                <td>Balance (SOL)</td>
                <td className="text-lg-end text-uppercase">
                    <SolBalance lamports={account.lamports} />
                </td>
            </tr>
            <tr>
                <td>Activation Status</td>
                <td className="text-lg-end text-uppercase">
                    {lookupTableAccount.isActive() ? 'Active' : 'Deactivated'}
                </td>
            </tr>
            <tr>
                <td>Last Extended Slot</td>
                <td className="text-lg-end">
                    {lookupTableAccount.state.lastExtendedSlot === 0 ? (
                        'None (Empty)'
                    ) : (
                        <Slot slot={lookupTableAccount.state.lastExtendedSlot} link />
                    )}
                </td>
            </tr>
            <tr>
                <td>Authority</td>
                <td className="text-lg-end">
                    {lookupTableAccount.state.authority === undefined ? (
                        'None (Frozen)'
                    ) : (
                        <Address pubkey={lookupTableAccount.state.authority} alignRight link />
                    )}
                </td>
            </tr>
        </AccountCard>
    );
}

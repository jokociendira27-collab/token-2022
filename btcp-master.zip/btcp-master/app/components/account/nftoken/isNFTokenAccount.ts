import { PublicKey } from '@solana/web3.js';

import { toBase64 } from '@/app/shared/lib/bytes';
import { invariant } from '@/app/shared/lib/invariant';
import { Logger } from '@/app/shared/lib/logger';

import { Account } from '../../../providers/accounts';
import { NFTOKEN_ADDRESS } from './nftoken';
import { NftokenTypes } from './nftoken-types';

export function isNFTokenAccount(account: Account): boolean {
    return Boolean(account.owner.toBase58() === NFTOKEN_ADDRESS && account.data.raw);
}

const nftokenAccountDisc = 'IbRbNewPP2E=';

export const parseNFTokenNFTAccount = (account: Account): NftokenTypes.NftAccount | null => {
    if (!isNFTokenAccount(account)) {
        return null;
    }

    try {
        invariant(account.data.raw, 'isNFTokenAccount guarantees raw account data');
        const parsed = NftokenTypes.nftAccountLayout.decode(account.data.raw);

        if (!parsed) {
            return null;
        }

        if (toBase64(new Uint8Array(parsed.discriminator)) !== nftokenAccountDisc) {
            return null;
        }

        return {
            address: account.pubkey.toBase58(),
            authority: new PublicKey(parsed.authority).toBase58(),
            authority_can_update: Boolean(parsed.authority_can_update),
            collection: new PublicKey(parsed.collection).toBase58(),

            delegate: new PublicKey(parsed.delegate).toBase58(),
            holder: new PublicKey(parsed.holder).toBase58(),

            // eslint-disable-next-line no-restricted-syntax -- remove null bytes from metadata URL
            metadata_url: parsed.metadata_url?.replace(/\0/g, '') ?? null,
        };
    } catch (e) {
        Logger.error(e);
        return null;
    }
};

const collectionAccountDisc = 'RQLwA3YS2fI=';
export const parseNFTokenCollectionAccount = (account: Account): NftokenTypes.CollectionAccount | null => {
    if (!isNFTokenAccount(account)) {
        return null;
    }

    try {
        invariant(account.data.raw, 'isNFTokenAccount guarantees raw account data');
        const parsed = NftokenTypes.collectionAccountLayout.decode(account.data.raw);

        if (!parsed) {
            return null;
        }
        if (toBase64(new Uint8Array(parsed.discriminator)) !== collectionAccountDisc) {
            return null;
        }

        return {
            address: account.pubkey.toBase58(),
            authority: parsed.authority,
            authority_can_update: Boolean(parsed.authority_can_update),
            // eslint-disable-next-line no-restricted-syntax -- remove null bytes from metadata URL
            metadata_url: parsed.metadata_url?.replace(/\0/g, '') ?? null,
        };
    } catch (e) {
        Logger.error(e);
        return null;
    }
};

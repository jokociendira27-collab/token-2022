import { CompressedNftAccountHeader } from '@components/account/CompressedNftCard';
import { MetaplexNFTHeader } from '@components/account/MetaplexNFTHeader';
import { isNFTokenAccount } from '@components/account/nftoken/isNFTokenAccount';
import { NFTokenAccountHeader } from '@components/account/nftoken/NFTokenAccountHeader';
import { isMetaplexNFT } from '@entities/nft';
import {
    Account,
    isTokenProgramData,
    isUpgradeableLoaderAccountData,
    TokenProgramData,
    useMintAccountInfo,
} from '@providers/accounts';
import { useMetadataJsonLink } from '@providers/compressed-nft';
import { MintAccountInfo } from '@validators/accounts/token';
import { MetadataPointer, TokenMetadata } from '@validators/accounts/token-extension';
import Image from 'next/image';
import React, { Suspense, useMemo } from 'react';
import { ErrorBoundary } from 'react-error-boundary';
import { create } from 'superstruct';

import { ProgramHeader } from '@/app/components/shared/account/ProgramHeader';
import { getProxiedUri } from '@/app/features/metadata/utils';
import TokenLogoPlaceholder from '@/app/img/logos-solana/low-contrast-solana-logo.svg';
import { type FullTokenInfo, isRedactedTokenAddress } from '@/app/utils/token-info';

export function AccountHeader({
    address,
    account,
    tokenInfo,
    isTokenInfoLoading,
}: {
    address: string;
    account?: Account;
    tokenInfo?: FullTokenInfo;
    isTokenInfoLoading: boolean;
}) {
    const mintInfo = useMintAccountInfo(address);

    const parsedData = account?.data.parsed;

    const isToken = parsedData && isTokenProgramData(parsedData) && parsedData?.parsed.type === 'mint';
    const isProgram = parsedData && isUpgradeableLoaderAccountData(parsedData) && parsedData?.parsed.type === 'program';
    const isNativeProgram = Boolean(account?.executable);

    const fallback = (
        <div className="e-flex e-flex-col e-justify-center e-gap-1 md:e-min-h-[69px]">
            <h6 className="header-pretitle">Details</h6>
            <h2 className="header-title">Account</h2>
        </div>
    );

    if (isTokenInfoLoading) return fallback;

    if (isMetaplexNFT(parsedData, mintInfo) && parsedData.nftData) {
        return <MetaplexNFTHeader nftData={parsedData.nftData} address={address} />;
    }

    const nftokenNFT = account && isNFTokenAccount(account);
    if (nftokenNFT && account) {
        return <NFTokenAccountHeader account={account} />;
    }

    if (isToken && !isTokenInfoLoading) {
        if (isRedactedTokenAddress(address)) {
            return (
                <TokenMintHeader address={address} mintInfo={mintInfo} parsedData={undefined} tokenInfo={undefined} />
            );
        }
        return <TokenMintHeader address={address} mintInfo={mintInfo} parsedData={parsedData} tokenInfo={tokenInfo} />;
    }

    if (isProgram) {
        return <ProgramHeader address={address} parsedData={parsedData} />;
    }

    if (isNativeProgram) {
        return <ProgramHeader address={address} />;
    }

    if (account) {
        return (
            <ErrorBoundary fallback={fallback}>
                <Suspense fallback={fallback}>
                    <CompressedNftAccountHeader account={account} fallback={fallback} />
                </Suspense>
            </ErrorBoundary>
        );
    }
    return fallback;
}

function TokenMintHeader({
    address,
    tokenInfo,
    mintInfo,
    parsedData,
}: {
    address: string;
    tokenInfo?: FullTokenInfo;
    mintInfo?: MintAccountInfo;
    parsedData?: TokenProgramData;
}): JSX.Element {
    const metadataExtension = mintInfo?.extensions?.find(
        ({ extension }: { extension: string }) => extension === 'tokenMetadata',
    );
    const metadataPointerExtension = mintInfo?.extensions?.find(
        ({ extension }: { extension: string }) => extension === 'metadataPointer',
    );

    const defaultCard = useMemo(
        () => <TokenMintHeaderCard token={tokenInfo ? tokenInfo : { logoURI: undefined, name: undefined }} />,
        [tokenInfo],
    );

    if (metadataPointerExtension && metadataExtension) {
        return (
            <>
                <ErrorBoundary fallback={defaultCard}>
                    <Suspense fallback={defaultCard}>
                        <Token22MintHeader
                            address={address}
                            metadataExtension={metadataExtension as any}
                            metadataPointerExtension={metadataPointerExtension as any}
                        />
                    </Suspense>
                </ErrorBoundary>
            </>
        );
    }
    // Fall back to legacy token list when there is stub metadata (blank uri), updatable by default by the mint authority
    else if (!parsedData?.nftData?.metadata.uri && tokenInfo) {
        return defaultCard;
    } else if (parsedData?.nftData) {
        const token = {
            logoURI: parsedData?.nftData?.json?.image,
            name: parsedData?.nftData?.json?.name ?? parsedData?.nftData.metadata.name,
            symbol: parsedData?.nftData?.metadata.symbol,
        };
        return <TokenMintHeaderCard token={token} />;
    } else if (tokenInfo) {
        return defaultCard;
    }
    return defaultCard;
}

function Token22MintHeader({
    address,
    metadataExtension,
    metadataPointerExtension,
}: {
    address: string;
    metadataExtension: { extension: 'tokenMetadata'; state?: any };
    metadataPointerExtension: { extension: 'metadataPointer'; state?: any };
}) {
    const tokenMetadata = create(metadataExtension.state, TokenMetadata);
    const { metadataAddress } = create(metadataPointerExtension.state, MetadataPointer);
    const metadata = useMetadataJsonLink(getProxiedUri(tokenMetadata.uri));

    const headerTokenMetadata = {
        logoURI: '',
        name: tokenMetadata.name,
        symbol: tokenMetadata.symbol,
    };
    if (metadata) {
        headerTokenMetadata.logoURI = metadata.image;
    }

    // Handles the basic case where MetadataPointer is referencing the Token Metadata extension directly
    // Does not handle the case where MetadataPointer is pointing at a separate account.
    if (metadataAddress?.toString() === address) {
        return <TokenMintHeaderCard token={headerTokenMetadata} />;
    }
    throw new Error('Metadata loading for non-token 2022 programs is not yet supported');
}

function TokenMintHeaderCard({
    token,
}: {
    token: { name?: string | undefined; logoURI?: string | undefined; symbol?: string | undefined };
}) {
    const logoURI = token.logoURI ? getProxiedUri(token.logoURI) : undefined;
    return (
        <div className="row align-items-center">
            <div className="col-auto">
                <div className="avatar avatar-lg header-avatar-top">
                    {logoURI ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                            src={logoURI}
                            alt="Token logo"
                            height={64}
                            width={64}
                            className="avatar-img rounded-circle border border-4 border-body"
                        />
                    ) : (
                        <Image
                            src={TokenLogoPlaceholder}
                            alt="Token logo placeholder"
                            height={64}
                            width={64}
                            className="e-h-full e-w-full e-rounded-full e-border e-border-gray-200 e-object-cover"
                        />
                    )}
                </div>
            </div>

            <div className="col ms-n3 ms-md-n2">
                <h6 className="header-pretitle">Token</h6>
                <h2 className="header-title">{token?.name || 'Unknown Token'}</h2>
                <div className="header-pretitle no-overflow-with-ellipsis">
                    {token?.symbol ? token.symbol : 'No Symbol was found'}
                </div>
            </div>
        </div>
    );
}

'use client';

import { AccountHeader } from '@components/common/Account';
import { useRefreshAccount } from '@entities/account';
import { useCluster } from '@providers/cluster';
import { PublicKey } from '@solana/web3.js';
import { Cluster } from '@utils/cluster';
import { useMemo } from 'react';
import useSWR from 'swr';

import { populatePartialParsedTokenExtension } from '@/app/utils/token-extension';
import { getTokenInfo, getTokenInfoSwrKey } from '@/app/utils/token-info';
import { TokenExtension } from '@/app/validators/accounts/token-extension';

import { LoadingCard } from '../common/LoadingCard';
import { TokenExtensionsSection } from './TokenExtensionsSection';
import { ParsedTokenExtension } from './types';

async function fetchTokenInfo([_, address, cluster, url]: ['get-token-info', string, Cluster, string]) {
    return await getTokenInfo(new PublicKey(address), cluster, url);
}

export function TokenExtensionsCard({
    decimals,
    address,
    extensions: mintExtensions,
}: {
    decimals: number;
    address: string;
    extensions: TokenExtension[];
}) {
    const { cluster, url } = useCluster();
    const refresh = useRefreshAccount();
    const swrKey = useMemo(() => getTokenInfoSwrKey(address, cluster, url), [address, cluster, url]);
    const { data: tokenInfo, isLoading } = useSWR(swrKey, fetchTokenInfo);

    const extensions = populateTokenExtensions(mintExtensions);

    // check for nullish decimals to satisty constraint for required decimals.
    if (isLoading) {
        return <LoadingCard />;
    } else if (tokenInfo && tokenInfo.decimals !== null && decimals !== tokenInfo.decimals) {
        throw new Error('Can not fetch token info.');
    }

    const symbol =
        mintExtensions.find(({ extension }) => extension === 'tokenMetadata')?.state.symbol || tokenInfo?.symbol;

    return (
        <div className="card">
            <AccountHeader
                title="Extensions"
                analyticsSection="extensions_section"
                refresh={() => refresh(new PublicKey(address), 'parsed')}
            />
            <div className="card-body p-0 e-overflow-x-scroll">
                <TokenExtensionsSection
                    address={address}
                    decimals={decimals}
                    extensions={mintExtensions}
                    parsedExtensions={extensions}
                    symbol={symbol}
                />
            </div>
        </div>
    );
}

function populateTokenExtensions(extensions: TokenExtension[]): ParsedTokenExtension[] {
    const result = extensions.reduce((acc, { extension, state }) => {
        const data = populatePartialParsedTokenExtension(extension);
        acc.set(extension, {
            ...data,
            extension: extension,
            parsed: state,
        });

        return acc;
    }, new Map<string, ParsedTokenExtension>());

    return Array.from(result.values());
}
